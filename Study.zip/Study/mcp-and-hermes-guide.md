# MCP 与 Hermes Agent 入门指南

> 面向中文母语的 Agent 工程学习者  
> 资料核对日期：2026-06-06

## 这份文档解决什么问题

学习 Agent 工程时，经常会同时看到这些名词：

```text
LLM
Agent
Tool
Skill
Memory
MCP
Hermes
```

它们不在同一个层次，很容易被混在一起。

这份文档重点回答：

- MCP 是什么？
- MCP 解决了什么问题？
- MCP 的 Host、Client、Server 分别是什么？
- Tool、Resource、Prompt 有什么区别？
- Hermes 是模型还是 Agent？
- Hermes Agent 和 MCP 是什么关系？
- Skill、MCP、Memory、Agent 分别负责什么？

## 先看结论

```text
MCP 是协议。
Hermes Agent 是一个完整的 Agent 应用和运行时。
Hermes 模型是 Nous Research 的大语言模型系列。
```

它们之间不是竞争关系。

Hermes Agent 可以使用 MCP，连接 GitHub、数据库、浏览器、文件系统和企业内部服务。

可以用一个类比快速理解：

```text
LLM               = 大脑
Agent             = 能思考和行动的完整系统
Hermes Agent      = 一种具体的 Agent 系统
Tool              = Agent 的手
MCP               = Agent 连接外部工具的统一接口标准
Skill             = Agent 的专业操作手册
Memory            = Agent 长期保存的信息
```

# 第一部分：什么是 MCP

## MCP 的定义

MCP 全称是 Model Context Protocol，中文可以翻译为“模型上下文协议”。

它是一种开放协议，用来标准化 AI 应用与外部数据源、工具和服务之间的连接方式。

一句话理解：

> MCP 让不同 Agent 用统一方式发现和调用外部能力。

MCP 本身不是：

- 大语言模型
- Agent
- 数据库
- 插件市场
- 某一个具体工具

MCP 是一套通信规范。

它规定：

- Agent 如何发现外部工具
- 工具如何声明输入和输出
- Agent 如何调用工具
- 外部系统如何返回结果
- Agent 如何读取外部资源
- 客户端和服务端如何协商能力

## MCP 为什么出现

假设没有 MCP，你要让多个 Agent 连接多个外部系统。

```text
Claude -> GitHub
Claude -> Slack
Claude -> PostgreSQL

Codex -> GitHub
Codex -> Slack
Codex -> PostgreSQL

Hermes -> GitHub
Hermes -> Slack
Hermes -> PostgreSQL
```

每个 Agent 都要为每个外部系统写一套专用集成。

当 Agent 和工具越来越多时，集成数量会快速增长。

有了 MCP 后，可以变成：

```text
Claude  ─┐
Codex   ─┼─ MCP 协议 ─ GitHub MCP Server
Hermes  ─┤           ├ Slack MCP Server
Cursor  ─┘           └ PostgreSQL MCP Server
```

Agent 只需要支持 MCP Client，外部服务只需要提供 MCP Server。

这和 USB 的思路相似：

```text
USB 统一了电脑连接外设的方式。
MCP 统一了 Agent 连接外部能力的方式。
```

## MCP 的三个核心角色

MCP 使用 Host、Client、Server 架构。

### 1. MCP Host

Host 是承载 Agent 和模型的 AI 应用。

常见 Host 可以是：

- Codex
- Claude Desktop
- Claude Code
- VS Code
- Cursor
- Hermes Agent
- 自己开发的 Agent 应用

Host 负责：

- 与用户交互
- 管理模型
- 管理会话上下文
- 管理 MCP Client
- 决定连接哪些 MCP Server
- 控制权限和用户确认

### 2. MCP Client

Client 是 Host 内部负责连接某个 MCP Server 的组件。

通常一个 Client 对应一个 Server 连接。

例如 Hermes Agent 同时连接：

```text
GitHub MCP Server
PostgreSQL MCP Server
Filesystem MCP Server
```

Hermes 内部会分别维护对应的 MCP Client 连接。

Client 负责：

- 与 Server 建立连接
- 协商协议版本和能力
- 获取工具列表
- 调用工具
- 读取资源
- 获取 Prompt 模板
- 接收通知和执行结果

### 3. MCP Server

Server 是向 Agent 暴露外部能力的程序。

例如：

```text
GitHub MCP Server       -> 查询 Issue、创建 PR、搜索代码
PostgreSQL MCP Server   -> 查询数据库、读取表结构
Filesystem MCP Server   -> 读取和修改文件
Slack MCP Server        -> 读取和发送消息
Browser MCP Server      -> 操作浏览器
Company MCP Server      -> 调用公司内部业务 API
```

MCP Server 可以运行在：

- 本机进程
- Docker 容器
- 公司内网服务器
- 云服务
- 第三方托管平台

## MCP 架构图

```mermaid
flowchart LR
    U["用户"] --> H["MCP Host<br/>Hermes、Codex、Claude 等"]
    H --> M["大语言模型"]
    H --> C1["MCP Client"]
    H --> C2["MCP Client"]
    C1 --> S1["GitHub MCP Server"]
    C2 --> S2["数据库 MCP Server"]
    S1 --> G["GitHub"]
    S2 --> D["PostgreSQL"]
```

## MCP Server 的三个核心能力

MCP Server 主要可以暴露三类能力：

```text
Tools
Resources
Prompts
```

### Tools：可执行动作

Tool 是模型可以主动调用的函数。

例子：

```text
create_issue
send_message
query_database
write_file
book_hotel
create_calendar_event
```

一个 Tool 通常会声明：

```text
名称
用途描述
输入参数
输入参数类型
输出结果
```

例如：

```json
{
  "name": "get_weather",
  "description": "查询指定城市的天气",
  "inputSchema": {
    "type": "object",
    "properties": {
      "city": {
        "type": "string"
      }
    },
    "required": ["city"]
  }
}
```

模型看到这个定义后，可以决定什么时候调用它。

### Resources：提供上下文的数据

Resource 是供 Agent 读取的上下文数据。

例子：

```text
数据库表结构
项目 README
API 文档
知识库文章
配置文件
客户资料
日历内容
```

Tool 更像“执行动作”，Resource 更像“读取资料”。

```text
Tool：查询订单
Resource：订单表结构说明
```

### Prompts：可复用交互模板

Prompt 是 Server 提供的可复用提示模板。

例子：

```text
生成周报
分析数据库
总结会议
制定旅行计划
执行代码审查
```

Prompt 可以告诉 Agent：

- 应该采用什么流程
- 应该读取哪些 Resource
- 应该调用哪些 Tool
- 最后应该输出什么格式

## Tools、Resources、Prompts 的区别

| 类型 | 核心作用 | 谁主要控制 | 示例 |
|---|---|---|---|
| Tool | 执行动作 | 模型决定何时调用 | 创建 Issue、查询数据库 |
| Resource | 提供上下文 | 应用或用户选择读取 | 表结构、文档、记录 |
| Prompt | 提供任务模板 | 用户选择或应用触发 | 代码审查、会议总结 |

简单记忆：

```text
Tool     = 做事情
Resource = 看资料
Prompt   = 按模板工作
```

## MCP 的通信方式

MCP 当前常见的传输方式有两种。

### Stdio

通过标准输入和标准输出通信。

适合：

- 本机 MCP Server
- 本地文件访问
- 本地命令行工具
- 低延迟进程通信

调用关系类似：

```text
Hermes 启动本地 MCP Server 子进程
Hermes 和子进程通过 stdin/stdout 通信
```

### Streamable HTTP

通过 HTTP 与远程 MCP Server 通信。

适合：

- 云端 MCP 服务
- 企业内部 MCP 服务
- 多用户共享服务
- OAuth 鉴权服务

调用关系类似：

```text
Hermes -> HTTPS -> 企业 MCP Server -> 内部 API
```

## 一个完整 MCP 调用过程

假设用户对 Hermes 说：

```text
帮我查询 GitHub 上所有标记为 bug 的开放 Issue，
然后为登录超时问题创建一个新 Issue。
```

执行过程：

```text
1. 用户把任务交给 Hermes。
2. Hermes 把任务和可用工具交给大语言模型。
3. 模型判断需要使用 GitHub MCP Server。
4. Hermes 的 MCP Client 获取 GitHub Server 的工具列表。
5. 模型调用 list_issues。
6. MCP Server 查询 GitHub API。
7. 查询结果返回 Hermes。
8. 模型分析结果并生成新 Issue 参数。
9. 模型调用 create_issue。
10. MCP Server 调用 GitHub API 创建 Issue。
11. Hermes 把最终结果告诉用户。
```

调用链：

```mermaid
sequenceDiagram
    participant U as 用户
    participant H as Hermes Agent
    participant L as 大语言模型
    participant C as MCP Client
    participant S as GitHub MCP Server
    participant G as GitHub API

    U->>H: 查询 bug Issue 并创建新 Issue
    H->>L: 提供任务和可用工具
    L->>H: 请求调用 list_issues
    H->>C: tools/call
    C->>S: 调用 list_issues
    S->>G: 查询 GitHub
    G-->>S: 返回 Issue
    S-->>H: 返回工具结果
    H->>L: 提供查询结果
    L->>H: 请求调用 create_issue
    H->>S: 创建 Issue
    S->>G: 调用 GitHub API
    G-->>H: 创建成功
    H-->>U: 返回最终结果
```

## MCP 的价值

MCP 主要解决四个问题。

### 1. 标准化

Agent 不需要为每个工具发明一套接入方式。

### 2. 可发现

Agent 可以动态获取 Server 提供的工具、Resource 和 Prompt。

### 3. 可组合

一个 Agent 可以同时连接多个 MCP Server。

例如：

```text
读取 Slack 需求
查询数据库
修改 GitHub 代码
更新 Linear Issue
发送完成通知
```

### 4. 降低平台绑定

同一个 MCP Server 可以被不同 MCP Host 使用。

你开发的企业数据库 MCP Server，可以同时提供给：

```text
Codex
Claude
Hermes
Cursor
VS Code
内部 Agent 平台
```

## MCP 不会自动解决什么

MCP 只解决“标准连接”问题，不会自动解决：

- 模型是否聪明
- Agent 是否会正确规划
- 工具描述是否清楚
- 权限是否安全
- 数据是否正确
- Prompt 是否合理
- Agent 是否会选择正确工具
- 工具执行失败后的恢复策略

错误理解：

```text
接入 MCP 后，Agent 就会自动变聪明。
```

正确理解：

```text
接入 MCP 后，Agent 获得了更标准的外部能力。
但如何选择、组合和安全使用这些能力，仍然依赖 Agent 设计。
```

## MCP 的安全风险

MCP Server 能访问文件、数据库、浏览器和第三方账号，因此必须把它当成真实程序，而不是普通文本插件。

需要重点注意：

- 不要安装来源不明的 MCP Server。
- 不要把完整环境变量全部传给本地 Server。
- 对写入、删除、支付、发送消息等操作保留用户确认。
- 对工具做白名单和最小权限控制。
- 不要让数据库账号拥有不必要的写权限。
- 不要在配置文件中提交 Token 和密钥。
- 防止外部内容中的 Prompt Injection 诱导 Agent 调用危险工具。
- 对远程 MCP Server 使用可靠认证和 HTTPS。
- 记录关键工具调用，方便审计。

最重要的原则：

```text
Agent 能看到的工具越少，权限越容易控制。
Agent 拥有的权限越小，错误执行的影响越小。
```

# 第二部分：什么是 Hermes

## “Hermes”有两个常见含义

在 Agent 和大模型领域，Hermes 至少有两个常见含义：

```text
1. Hermes Agent
2. Hermes 大语言模型系列
```

它们都与 Nous Research 有关，但不是同一个东西。

## Hermes Agent 是什么

Hermes Agent 是 Nous Research 开发的开源 Agent 应用和运行时。

它不是一种协议，也不只是一个模型调用脚本。

它把构建一个可长期使用的 Agent 所需要的多个模块组合在一起：

- 大语言模型接入
- Agent Loop
- Tool 调用
- MCP 集成
- Skill 系统
- 持久记忆
- 会话存储和搜索
- 终端与文件操作
- 浏览器能力
- 定时任务
- 消息平台接入
- 权限控制和隔离

可以把 Hermes Agent 理解成：

> 一个可以安装在电脑或服务器上的开源个人 Agent 系统。

## Hermes Agent 的核心结构

简化后的结构：

```mermaid
flowchart TD
    U["用户"] --> E["CLI / 桌面端 / 消息平台"]
    E --> A["Hermes Agent Loop"]
    A --> L["LLM Provider"]
    A --> S["Skills"]
    A --> M["Memory"]
    A --> T["内置 Tools"]
    A --> MC["MCP Client"]
    MC --> MS["外部 MCP Servers"]
    T --> OS["文件、终端、浏览器"]
    MS --> EX["GitHub、数据库、企业 API"]
```

## Hermes Agent 的 Agent Loop

Agent Loop 可以理解为：

```text
接收用户目标
-> 构建上下文
-> 调用模型推理
-> 模型选择工具
-> 执行工具
-> 把结果交回模型
-> 继续推理或完成任务
```

伪代码：

```python
while not task_finished:
    context = build_context(
        conversation=conversation,
        skills=skills,
        memory=memory,
        available_tools=tools,
    )

    response = model.generate(context)

    if response.has_tool_call:
        result = execute_tool(response.tool_call)
        conversation.add(result)
    else:
        return response.text
```

真正的 Agent 工程通常还要处理：

- 上下文压缩
- 工具调用失败
- 权限确认
- 超时和重试
- 并行工具调用
- 会话持久化
- 模型切换
- Token 和成本控制
- Prompt Injection
- 日志和可观测性

Hermes Agent 就是在提供这些 Agent 运行时能力。

## Hermes Agent 的 Skill

Hermes 的 Skill 是按需加载的知识和工作流文档。

它采用渐进加载方式：

```text
先看到 Skill 的名称和描述
-> 任务匹配时读取完整 SKILL.md
-> 需要详细资料时再读取 references
```

Skill 解决的是：

```text
Agent 应该怎么完成某类任务？
```

例如代码审查 Skill 会告诉 Agent：

```text
先看改动范围
优先找 bug 和回归风险
检查测试
按严重程度输出
```

## Hermes Agent 的 Memory

Memory 用来保存跨会话仍然有价值的信息。

例如：

```text
用户偏好使用 TypeScript
项目使用 pnpm
测试命令是 pnpm test
生产环境不能直接执行数据库写操作
用户希望回答使用中文
```

Memory 解决的是：

```text
Agent 长期应该记住什么？
```

Skill 和 Memory 不一样：

```text
Skill 记录“做事的方法”
Memory 记录“用户、环境和项目事实”
```

## Hermes 大语言模型是什么

Nous Research 也发布了 Hermes 系列大语言模型。

Hermes 模型属于 LLM，是 Agent 可以选择使用的“大脑”之一。

Hermes Agent 则是完整的应用和运行时。

两者关系：

```text
Hermes 模型 = 大脑
Hermes Agent = 包含大脑、工具、记忆、Skill 和执行循环的完整系统
```

Hermes Agent 不一定只能使用 Hermes 模型。它可以连接多种模型提供方或兼容接口。

因此，不要把下面两句话混为一谈：

```text
“我正在使用 Hermes 模型。”
“我正在运行 Hermes Agent。”
```

# 第三部分：Hermes Agent 和 MCP 的关系

## 它们不是同一层的东西

| 对比项 | MCP | Hermes Agent |
|---|---|---|
| 本质 | 开放协议 | Agent 应用和运行时 |
| 主要作用 | 连接外部工具和数据 | 理解目标、推理、执行任务 |
| 是否包含模型 | 不包含 | 可以连接模型 |
| 是否包含 Agent Loop | 不包含 | 包含 |
| 是否提供 Memory | 协议本身不负责 | 提供持久记忆机制 |
| 是否提供 Skill | 协议核心不等于 Skill 系统 | 提供 Skill 系统 |
| 是否能调用 Tool | 定义标准调用方式 | 可以通过内置 Tool 或 MCP 调用 |
| 是否能独立完成任务 | 不能 | 可以 |

最简单的记忆：

```text
MCP 是接口标准。
Hermes Agent 是使用这些接口完成任务的 Agent 系统。
```

## Hermes Agent 可以作为 MCP Host

Hermes 可以连接外部 MCP Server。

例如：

```text
Hermes
├── GitHub MCP Server
├── Filesystem MCP Server
├── PostgreSQL MCP Server
├── Browser MCP Server
└── Company API MCP Server
```

Hermes 启动时可以发现 MCP Server 暴露的工具，并把这些工具注册到自己的工具系统中。

模型在推理过程中可以像调用内置工具一样调用 MCP 工具。

## Hermes Agent 也可以作为 MCP Server

根据 Hermes 官方文档，Hermes 也可以把自己的部分能力通过 MCP Server 暴露给其他 MCP Client。

例如：

```text
Codex -> Hermes MCP Server -> Telegram / Discord / Slack
```

这意味着其他 Agent 可以通过 MCP 使用 Hermes 的消息平台能力。

所以 Hermes 可以同时扮演：

```text
MCP Host / Client：连接外部 MCP Server
MCP Server：向其他 Agent 暴露部分 Hermes 能力
```

## Hermes 中的 MCP 配置示例

下面是一个本地文件系统 MCP Server 的概念示例：

```yaml
mcp_servers:
  project_files:
    command: "npx"
    args:
      - "-y"
      - "@modelcontextprotocol/server-filesystem"
      - "/home/user/projects"
```

启动 Hermes 后，可以提出：

```text
读取 /home/user/projects 下的项目，
总结目录结构并找出主要入口文件。
```

Hermes 会：

```text
1. 发现 project_files MCP Server。
2. 获取该 Server 暴露的工具。
3. 让模型判断需要调用哪些工具。
4. 通过 MCP Client 执行文件读取。
5. 把结果交回模型分析。
6. 输出项目结构总结。
```

# 第四部分：Skill、MCP、Tool、Memory 的关系

## 四个概念分别负责什么

| 概念 | 解决的问题 |
|---|---|
| Tool | Agent 能做什么动作？ |
| MCP | Agent 如何用统一方式连接外部能力？ |
| Skill | Agent 应该怎样完成某类任务？ |
| Memory | Agent 应该长期记住什么？ |

假设用户说：

```text
帮我审查这个 GitHub PR，并把严重问题写成 Issue。
```

各模块的职责：

```text
Skill：
告诉 Agent 如何做高质量代码审查。

MCP：
提供连接 GitHub 的统一协议。

Tool：
提供读取 PR、读取 Diff、创建 Issue 的具体动作。

Memory：
记住项目使用 TypeScript、测试命令和团队规范。

LLM：
理解代码、发现问题、判断严重程度。

Agent Loop：
协调 Skill、Memory、模型和 Tool，直到任务完成。
```

## 完整调用关系

```mermaid
flowchart LR
    U["用户目标"] --> A["Agent Loop"]
    S["Skill<br/>怎么做"] --> A
    M["Memory<br/>记住什么"] --> A
    A --> L["LLM<br/>理解和决策"]
    L --> T["Tool Call<br/>执行动作"]
    T --> C["MCP Client<br/>标准连接"]
    C --> SV["MCP Server"]
    SV --> E["GitHub / 数据库 / 企业系统"]
    E --> A
    A --> R["最终结果"]
```

# 第五部分：什么时候应该开发 MCP Server

适合开发 MCP Server 的情况：

- 需要让多个 Agent 使用同一个内部系统。
- 已有 API，但不同 Agent 的集成方式不统一。
- 需要向 Agent 暴露数据库、知识库或业务工具。
- 希望工具有清晰的输入输出 Schema。
- 需要统一认证、权限、日志和审计。
- 希望未来可以替换 Agent Host。

不一定需要 MCP 的情况：

- 只在单个程序内部使用一个简单函数。
- 功能不会被其他 Agent 或客户端复用。
- 现有框架的原生 Tool 已经足够。
- MCP 会引入不必要的部署和认证复杂度。

判断原则：

```text
如果能力需要跨 Agent、跨应用复用，优先考虑 MCP。
如果能力只在单个 Agent 内部使用，原生 Tool 可能更简单。
```

# 第六部分：怎样设计一个好的 MCP Server

## 1. Tool 颗粒度要清楚

差：

```text
manage_github
```

这个 Tool 什么都做，输入输出难以约束。

好：

```text
list_issues
get_issue
create_issue
update_issue
search_code
```

一个 Tool 尽量负责一个清晰动作。

## 2. description 要告诉模型什么时候使用

差：

```text
查询数据。
```

好：

```text
根据订单号查询订单详情，包括状态、金额、创建时间和支付状态。
当用户询问单个订单的当前信息时使用。
```

Tool description 也是给模型看的 Prompt。

## 3. 输入 Schema 要严格

应该明确：

- 哪些参数必填
- 参数类型
- 枚举值
- 长度和范围
- 日期格式
- ID 格式

不要让模型靠猜测拼接自由文本。

## 4. 输出要结构化

差：

```text
订单看起来没有支付，大概是昨天创建的。
```

好：

```json
{
  "order_id": "ORD-1001",
  "status": "pending",
  "payment_status": "unpaid",
  "created_at": "2026-06-05T10:30:00+08:00"
}
```

结构化输出更方便 Agent 继续推理和组合工具。

## 5. 区分读取和写入

读取工具和修改工具应该明确分开。

例如：

```text
get_customer
update_customer
delete_customer
```

这样 Host 可以：

- 默认开放读取工具
- 对写入工具要求确认
- 禁止危险删除工具

## 6. 做最小权限控制

不要因为 Server 能访问整个系统，就把所有能力暴露给 Agent。

应该：

- 使用只读数据库账号完成查询
- 限制文件系统根目录
- 限制可调用的 API
- 对危险工具设置审批
- 对不同用户使用不同权限

## 7. 提供可观察性

至少记录：

- 谁调用了工具
- 调用了哪个工具
- 使用了哪些参数
- 是否成功
- 耗时
- 错误类型
- 是否执行了写操作

# 第七部分：Agent 工程师的学习路线

建议按下面顺序学习。

## 第一阶段：理解 Agent 基础

学习：

```text
LLM
Prompt
Function Calling
Tool
Agent Loop
Context
Memory
Skill
```

目标：

```text
能够手写一个“模型 -> 工具 -> 结果 -> 模型”的最小 Agent Loop。
```

## 第二阶段：学习 MCP

学习：

```text
Host / Client / Server
Tools / Resources / Prompts
JSON-RPC
Stdio
Streamable HTTP
JSON Schema
认证和权限
```

目标：

```text
实现一个只读 MCP Server，
例如天气查询、文档搜索或数据库查询。
```

## 第三阶段：使用 Hermes Agent

练习：

```text
安装 Hermes Agent
配置一个模型
使用内置 Tool
创建一个 Skill
观察 Memory
连接一个本地 MCP Server
连接一个远程 MCP Server
限制危险工具
```

目标：

```text
理解完整 Agent 运行时如何协调模型、Skill、Memory 和 MCP。
```

## 第四阶段：构建企业级 MCP

练习：

```text
连接公司内部 API
增加 OAuth 或 Token 鉴权
增加权限控制
增加日志和审计
处理超时、重试、限流
区分读取和写入工具
进行 Prompt Injection 测试
```

目标：

```text
让 MCP Server 可以被多个 Agent 安全复用。
```

# 常见误区

## 误区 1：MCP 就是 Agent

错误。

MCP 只定义连接和通信方式，不负责完整 Agent 推理。

## 误区 2：Hermes Agent 就是 Hermes 模型

错误。

Hermes Agent 是完整运行时，Hermes 模型是 LLM。

## 误区 3：有了 MCP 就不需要 Skill

错误。

```text
MCP 解决“能连接什么”。
Skill 解决“应该怎么做”。
```

## 误区 4：MCP Tool 越多越好

错误。

工具太多会增加：

- 模型选择难度
- Token 消耗
- 工具调用错误
- 安全风险
- 命名冲突

应该只暴露当前任务真正需要的工具。

## 误区 5：MCP Server 只是一个 Prompt

错误。

MCP Server 是实际运行的程序，可以调用 API、访问文件和数据库。

因此它拥有真实权限，也会产生真实风险。

# 最终总结

## MCP

MCP 是 Agent 连接外部工具和数据的开放协议。

它通过 Host、Client、Server 架构，把外部能力标准化为：

```text
Tools
Resources
Prompts
```

MCP 解决的是：

```text
Agent 如何以统一方式连接和调用外部能力？
```

## Hermes Agent

Hermes Agent 是 Nous Research 开发的开源 Agent 应用和运行时。

它包含或整合：

```text
模型
Agent Loop
Tools
Skills
Memory
会话
MCP
终端
浏览器
消息平台
```

Hermes Agent 解决的是：

```text
如何让一个 Agent 长期运行、记住信息、使用工具并完成任务？
```

## Hermes 模型

Hermes 模型是大语言模型，是 Agent 可以使用的大脑之一。

它和 Hermes Agent 不是同一个东西。

## 三者关系

```text
Hermes 模型负责推理。
Hermes Agent 负责组织和执行任务。
MCP 负责连接外部工具与数据。
Skill 负责告诉 Agent 应该怎样工作。
Memory 负责保存长期有价值的信息。
```

最重要的一句话：

> MCP 是接口标准，Hermes Agent 是完整系统，Hermes 模型是系统可以使用的大脑。

# 官方参考资料

- [MCP 官方架构说明](https://modelcontextprotocol.io/docs/learn/architecture)
- [MCP Server 核心概念](https://modelcontextprotocol.io/docs/learn/server-concepts)
- [MCP 官方规范与文档仓库](https://github.com/modelcontextprotocol/modelcontextprotocol)
- [Hermes Agent 官方仓库](https://github.com/NousResearch/hermes-agent)
- [Hermes Agent 架构](https://hermes-agent.nousresearch.com/docs/developer-guide/architecture)
- [Hermes Agent MCP 集成](https://hermes-agent.nousresearch.com/docs/user-guide/features/mcp)
- [Hermes Agent Skill 系统](https://hermes-agent.nousresearch.com/docs/user-guide/features/skills)
- [Hermes Agent 持久记忆](https://hermes-agent.nousresearch.com/docs/user-guide/features/memory)
