# Agent Skill 写作指南

## 这份文档解决什么问题

这份文档面向中文母语的 Agent 工程学习者，目标是讲清楚三件事：

- Skill 是什么
- Skill 应该怎么写
- 什么样的 Skill 才算好

你可以把它当成从概念到实战的入门手册。

## 一句话定义

Skill 是写给 Agent 的可复用专业操作手册。

它不是普通提示词，也不是知识库文档，而是一套可以被 Agent 在特定任务中自动使用的工作流、约束、领域知识和工具说明。

更工程化地说：

```text
Prompt = 一次性任务说明
Skill = 某一类任务的长期工作流
Tool = Agent 可以调用的能力
Memory = Agent 长期记住的信息
System Prompt = Agent 的全局行为规则
```

## 用一个例子理解 Skill

假设你经常让 Agent 做代码审查。

普通 prompt 可能是：

```text
帮我 review 一下这段代码。
```

这个 prompt 太依赖 Agent 自己发挥。Agent 可能去看命名、格式、风格，也可能忽略真正重要的 bug。

如果你把代码审查沉淀成 Skill，它会变成：

```text
当用户要求 code review 时：
1. 先看变更范围
2. 优先找 bug、回归风险、边界条件、缺失测试
3. 按严重程度排序
4. 每个问题都给出文件、行号、原因和修改建议
5. 风格建议放在次要位置
6. 如果没有发现问题，也要说明剩余风险
```

这就是 Skill 的价值：把专家经验变成稳定流程，让 Agent 每次都按同一套高质量方法工作。

## Skill 适合解决哪些问题

适合写成 Skill 的任务通常有这些特征：

- 高频重复：代码审查、修 bug、写测试、生成周报、写 PRD、做数据分析。
- 有固定流程：debug、发布、回滚、CI 修复、安全审查。
- 有领域知识：公司内部指标口径、数据库 schema、API 规范、设计系统规范。
- 需要工具配合：处理 Excel、PDF、PPT、图片、日志、数据库查询。
- 容易出错：数据库迁移、线上事故排查、权限变更、支付链路修改。

不适合写成 Skill 的内容：

```text
你要认真。
你是高级工程师。
回答要详细。
帮我写好代码。
```

这些太泛，不是 Skill，只是风格要求。

## Skill 的标准目录结构

一个 Skill 通常是一个独立文件夹：

```text
skill-name/
├── SKILL.md
├── agents/
│   └── openai.yaml
├── scripts/
├── references/
└── assets/
```

各部分含义：

- `SKILL.md`：必须有。Skill 的入口文件，定义什么时候使用、怎么使用。
- `agents/openai.yaml`：推荐有。给界面展示用的元信息，比如显示名称、简短描述、默认提示。
- `scripts/`：可选。放稳定、可重复执行的脚本。
- `references/`：可选。放详细参考资料，比如 API 文档、数据库结构、业务规则。
- `assets/`：可选。放模板、图片、字体、样例文件等输出资源。

最重要的是 `SKILL.md`。

## SKILL.md 的基本结构

一个最小可用的 `SKILL.md` 长这样：

```markdown
---
name: code-review
description: Use when the user asks to review code, inspect pull request changes, identify bugs, or evaluate implementation risks.
---

# Code Review

## 目标

帮助 Agent 按工程审查标准检查代码变更，优先发现 bug、回归风险和缺失测试。

## 工作流

1. 先查看变更范围。
2. 理解改动的业务行为。
3. 优先检查 bug、边界条件、回归风险、安全问题和测试缺口。
4. 按严重程度输出问题。
5. 如果没有发现问题，明确说明没有发现阻塞问题，并指出剩余风险。

## 约束

- 不要把代码风格问题放在主要位置。
- 不要在没看代码的情况下泛泛而谈。
- 不要给没有文件和行号支撑的严重结论。

## 输出格式

先输出问题列表，再输出开放问题，最后给简短总结。
```

注意：

- `name` 建议用英文小写和短横线，例如 `code-review`。
- `description` 是触发条件，非常关键，建议写清楚这个 Skill 什么时候该用。
- 正文可以中文化，尤其是工作流、约束、输出格式。

## 怎么写一个 Skill

### 第一步：定义触发场景

先问自己：

```text
这个 Skill 应该在什么时候被使用？
什么时候不该使用？
```

差的写法：

```yaml
description: Help with code.
```

问题是太泛，Agent 不知道什么时候应该触发。

好的写法：

```yaml
description: Use when the user asks to review code, inspect pull request changes, identify bugs, evaluate test coverage, or find behavioral regressions.
```

这个描述清楚地覆盖了：

- review 代码
- 检查 PR
- 找 bug
- 看测试覆盖
- 找行为回归

### 第二步：写清楚目标

目标不是口号，而是这个 Skill 要稳定改善什么能力。

差：

```markdown
## 目标

写出好代码。
```

好：

```markdown
## 目标

在不做无关重构的前提下，帮助 Agent 找到 bug 根因、完成最小修复，并通过验证证明问题已经解决。
```

### 第三步：沉淀工作流

Skill 的核心是流程。

比如 debug Skill 的工作流可以这样写：

```markdown
## 工作流

1. 复现问题。
2. 收集报错、输入、环境和期望行为。
3. 找到最小失败路径。
4. 一次只提出一个假设。
5. 通过日志、测试或代码阅读验证假设。
6. 做最小范围修复。
7. 运行验证命令。
8. 说明根因、修改内容和验证结果。
```

这比“请认真 debug”有效得多。

### 第四步：写清楚约束

约束用来减少 Agent 的错误行为。

例如：

```markdown
## 约束

- 不要凭猜测直接改代码。
- 不要做无关重构。
- 不要在没有验证的情况下声称修复完成。
- 不要改变公开 API，除非用户明确要求。
```

约束越具体，Agent 越不容易跑偏。

### 第五步：定义输出格式

输出格式决定 Agent 最后交付的信息是否稳定。

例如代码审查 Skill：

```markdown
## 输出格式

按以下顺序输出：

1. 问题列表
2. 开放问题
3. 简短总结

每个问题必须包含：

- 严重程度
- 文件和行号
- 问题原因
- 具体修改建议
```

### 第六步：把详细资料放进 references

`SKILL.md` 不应该写成巨大的教程。详细资料应该拆到 `references/`。

例子：

```text
payment-debugging/
├── SKILL.md
└── references/
    ├── webhook.md
    ├── refund-flow.md
    └── subscription-schema.md
```

`SKILL.md` 里只写：

```markdown
## 参考资料

- 排查 Webhook 问题时，读取 `references/webhook.md`。
- 排查退款问题时，读取 `references/refund-flow.md`。
- 排查订阅状态问题时，读取 `references/subscription-schema.md`。
```

这样 Agent 只在需要时加载对应资料，不会浪费上下文。

### 第七步：能脚本化的就放进 scripts

如果一个步骤需要稳定、可重复、低错误率，就应该考虑写脚本。

适合放进 `scripts/` 的事情：

- 文件格式转换
- 日志解析
- 固定格式校验
- 批量生成文件
- 数据清洗
- 测试结果汇总

不适合脚本化的事情：

- 设计方案取舍
- 产品优先级判断
- 架构 tradeoff 分析
- 对代码意图的理解

## 什么是好的 Skill

一个好的 Skill 通常满足以下标准。

### 1. 触发条件清楚

Agent 只看 `description` 就能判断什么时候该用。

差：

```yaml
description: Helps with frontend.
```

好：

```yaml
description: Use when building or modifying React UI components, especially when layout, responsive behavior, design-system consistency, or interaction states matter.
```

### 2. 内容简洁，但关键

Skill 不是教材。它应该只写 Agent 执行任务必须知道的内容。

差：

```markdown
React 是一个用于构建用户界面的 JavaScript 库。
```

这类常识没有必要写进 Skill。

好：

```markdown
- 优先复用项目已有组件。
- 修改 UI 后必须检查桌面端和移动端布局。
- 不要在没有明确需求时引入新的设计系统。
```

### 3. 是流程，不是口号

差：

```markdown
写高质量代码，认真检查。
```

好：

```markdown
编辑代码前：
1. 找到现有实现模式。
2. 确认会影响哪些公开 API。
3. 为变化的行为补充或更新测试。
4. 运行相关验证命令。
```

### 4. 自由度合适

高风险任务要写得具体，低风险任务可以给 Agent 更多判断空间。

高自由度适合：

```text
写文档
写方案
UI 文案
需求分析
```

低自由度适合：

```text
数据库迁移
支付链路
权限系统
线上发布
安全审查
```

例如数据库迁移 Skill 应该具体到：

```markdown
1. 创建迁移文件。
2. 添加回滚逻辑。
3. 本地运行迁移。
4. 检查 schema diff。
5. 不要直接修改生产数据。
```

### 5. 有明确输出格式

好的 Skill 会让 Agent 输出稳定、可读、可检查。

例如：

```markdown
## 输出格式

- 根因
- 修改内容
- 验证结果
- 剩余风险
```

### 6. 支持渐进加载

不要把所有知识都塞进 `SKILL.md`。

推荐结构：

```text
SKILL.md：核心流程
references/：详细领域知识
scripts/：稳定工具
assets/：模板和资源
```

### 7. 可以被验证

好的 Skill 可以通过测试任务验证。

例如：

```text
给 code-review Skill 一个有 bug 的 PR，看它是否优先找 bug。
给 debugging Skill 一个失败测试，看它是否先复现再修复。
给 frontend Skill 一个 UI 修改任务，看它是否检查响应式和交互状态。
```

如果一个 Skill 无法验证，通常说明它写得太虚。

## 完整示例：系统化 Debug Skill

下面是一个偏实战的 Skill 示例。

```markdown
---
name: systematic-debugging
description: Use when investigating bugs, failing tests, runtime errors, regressions, flaky behavior, or unexpected output before proposing fixes.
---

# 系统化 Debug

## 目标

在修改代码前找到可信根因，避免凭猜测修 bug。

## 使用场景

当用户遇到以下情况时使用：

- 测试失败
- 运行时报错
- 行为和预期不一致
- 线上回归
- 偶发问题
- 输出结果异常

## 工作流

1. 复现问题。
2. 记录完整报错、输入、环境和期望行为。
3. 找到最小失败路径。
4. 一次只提出一个假设。
5. 用日志、测试或代码阅读验证假设。
6. 做最小范围修复。
7. 运行验证命令。
8. 说明根因、修复内容、验证结果和剩余风险。

## 约束

- 不要没有证据就改代码。
- 不要做无关重构。
- 不要跳过验证。
- 如果无法复现，明确说明缺少什么证据。

## 输出格式

按以下结构输出：

1. 根因
2. 修复
3. 验证
4. 剩余风险
```

## 完整示例：代码审查 Skill

```markdown
---
name: code-review
description: Use when reviewing code changes, pull requests, diffs, or implementation quality, especially to find bugs, regressions, missing tests, security risks, and edge cases.
---

# 代码审查

## 目标

帮助 Agent 像资深工程师一样审查代码，优先发现会影响正确性、稳定性、安全性和可维护性的真实问题。

## 工作流

1. 查看变更文件和变更范围。
2. 理解这次改动想改变什么行为。
3. 检查是否有逻辑 bug、边界条件、回归风险、安全风险、性能问题。
4. 检查是否缺少必要测试。
5. 按严重程度排序输出问题。
6. 如果没有发现问题，明确说明没有发现阻塞问题，并补充剩余风险。

## 约束

- 问题必须具体到文件和行号。
- 优先报告真实风险，不要优先报告风格偏好。
- 不要要求无关重构。
- 不要在证据不足时下确定结论。

## 输出格式

先输出 Findings。

每个 Finding 包含：

- 严重程度
- 文件和行号
- 问题描述
- 影响
- 建议修改

然后输出开放问题。

最后输出简短总结。
```

## 中文母语者写 Skill 的建议

建议采用“工程关键字英文，解释和流程中文”的写法。

应该保留英文的部分：

- `SKILL.md`
- `name`
- `description`
- `scripts`
- `references`
- `assets`
- 文件名和目录名
- 代码、命令、API 名称

可以中文化的部分：

- 目标
- 使用场景
- 工作流
- 约束
- 输出格式
- 示例
- 业务规则说明

推荐写法：

```markdown
## 工作流

1. 先读取相关代码。
2. 确认现有实现模式。
3. 做最小范围修改。
4. 运行验证命令。
5. 输出根因、修改内容和验证结果。
```

不推荐写法：

```markdown
## Workflow

1. Read context.
2. Implement robustly.
3. Be careful.
```

对中文母语者来说，工作流用中文会更直观，也更容易长期维护。

## 新手练习路线

如果你想成为 Agent 高级开发工程师，可以按这个顺序练习 Skill：

1. `code-review`：训练 Agent 找 bug 和风险。
2. `systematic-debugging`：训练 Agent 不凭猜测修 bug。
3. `test-writing`：训练 Agent 为行为变化补测试。
4. `frontend-implementation`：训练 Agent 按设计系统实现 UI。
5. `prd-to-plan`：训练 Agent 把需求拆成工程计划。
6. `release-checklist`：训练 Agent 稳定执行发布前检查。
7. `domain-analytics`：训练 Agent 使用业务指标、表结构和分析流程。

每个练习都用同一个骨架：

```markdown
---
name: skill-name
description: Use when ...
---

# Skill 名称

## 目标

[这个 Skill 要让 Agent 稳定做到什么]

## 使用场景

[什么时候使用]

## 工作流

1. [步骤 1]
2. [步骤 2]
3. [步骤 3]

## 约束

- [不能做什么]
- [必须遵守什么]

## 参考资料

- 遇到 [情况 A] 时，读取 `references/a.md`。
- 遇到 [情况 B] 时，读取 `references/b.md`。

## 输出格式

[Agent 最后应该怎么输出]

## 验证方式

[怎样证明这个任务完成了]
```

## Skill 质量检查清单

写完一个 Skill 后，用下面的问题检查：

- `description` 是否清楚说明了触发场景？
- 目标是否具体，而不是口号？
- 工作流是否能一步步执行？
- 是否写清楚了不能做什么？
- 输出格式是否稳定？
- 详细资料是否拆到了 `references/`？
- 可重复、易出错的步骤是否可以脚本化？
- 是否能用真实任务验证这个 Skill？
- `SKILL.md` 是否足够简洁？
- 是否避免了无意义的背景知识堆砌？

## 最终总结

Skill 是 Agent 工程里的专业工作流模块。

好的 Skill 不是把知识堆得越多越好，而是把专家在某类任务中的稳定做法沉淀下来，让 Agent 在正确的时机按正确流程行动。

一个好的 Skill 至少要做到：

```text
触发清楚
目标明确
流程稳定
约束具体
输出可控
资料分层
结果可验证
```

如果 Prompt 是你给 Agent 的一次性任务，那么 Skill 就是你给 Agent 装上的长期专业能力。
