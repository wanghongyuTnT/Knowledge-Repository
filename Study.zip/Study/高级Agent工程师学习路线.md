# 从零到高级 Agent 工程师学习路线

生成日期：2026-06-05  
目标读者：希望从零开始，逐步具备企业级 Agent 应用架构、开发、评测、部署和落地能力的工程师。

## 1. 目标画像

高级 Agent 工程师不只是会调模型 API，而是能够把大模型能力接入真实业务流程，设计可控、可观测、可评估、可持续迭代的智能系统。你最终应具备以下能力：

- 能判断一个需求适合用普通 LLM 调用、RAG、工作流 Agent、工具调用 Agent，还是多 Agent 系统。
- 能设计 prompt、上下文、工具、记忆、权限、审批、人机协同和失败兜底机制。
- 能基于 OpenAI Agents SDK、LangGraph、LlamaIndex、AutoGen、CrewAI 等框架做工程选型。
- 能把企业内部系统、数据库、SaaS、文件、浏览器、代码仓库等能力通过工具或 MCP 接入 Agent。
- 能建立 eval、trace、日志、成本、质量、延迟、安全和回归测试体系。
- 能从 0 到 1 推动公司落地 Agent：识别场景、设计 POC、验证 ROI、上线 MVP、扩展到平台化。

## 2. 总体学习路径

建议周期：6 到 9 个月。每天 1.5 到 2.5 小时，周末做项目。

| 阶段 | 时间 | 核心目标 | 产出 |
| --- | --- | --- | --- |
| 0. 编程与工程基础补齐 | 2-4 周 | Python、API、Git、后端、异步、数据库 | 一个可部署的 API 服务 |
| 1. LLM 应用基础 | 3-4 周 | Prompt、结构化输出、工具调用、流式响应 | 一个稳定的 LLM 助手 |
| 2. RAG 与知识工程 | 4-6 周 | 文档解析、向量检索、重排、引用、评测 | 企业知识库问答系统 |
| 3. 单 Agent 与工具使用 | 4-6 周 | 工具规划、函数调用、状态、错误恢复 | 可执行任务的个人工作流 Agent |
| 4. 工作流 Agent | 4-6 周 | 图式编排、确定性步骤、人类审批、长任务 | 可控业务流程自动化 |
| 5. 多 Agent 系统 | 3-5 周 | 角色分工、协作协议、仲裁、成本控制 | 多角色协作分析/研发 Agent |
| 6. AgentOps 与生产化 | 5-8 周 | Evals、Tracing、监控、安全、权限、部署 | 生产级 Agent 服务模板 |
| 7. 企业落地与平台化 | 持续 | 场景评估、ROI、治理、内部平台 | 公司 Agent 落地方案 |

## 3. 阶段 0：编程与工程基础

如果你已有 2 年以上后端或全栈经验，可以快速跳过；如果基础薄弱，这一阶段不能省。

### 必学能力

- Python：类型标注、虚拟环境、包管理、异常处理、日志、测试。
- Web API：FastAPI、HTTP、JSON Schema、鉴权、限流。
- 数据库：PostgreSQL、Redis、SQL 基础、事务、索引。
- 异步与任务队列：asyncio、Celery/RQ、消息队列基础。
- 工程协作：Git、Docker、CI、配置管理、环境变量。

### 推荐资料

- Python 官方教程：https://docs.python.org/3/tutorial/
- FastAPI 文档：https://fastapi.tiangolo.com/
- PostgreSQL 文档：https://www.postgresql.org/docs/
- Docker 文档：https://docs.docker.com/

### 实战项目

做一个“任务管理 API”：

- 支持用户创建任务、更新状态、查询列表。
- 支持后台任务，例如定时生成日报。
- 使用 PostgreSQL 持久化。
- 使用 Docker Compose 一键启动。
- 加入 pytest 测试。

### 验收标准

- 你能独立写一个 API 服务并部署到本地或云服务器。
- 你能解释接口设计、错误处理、日志、测试和数据库结构。
- 你能用 Docker 复现运行环境。

## 4. 阶段 1：LLM 应用基础

### 必学概念

- Token、上下文窗口、系统提示、开发者提示、用户提示。
- Temperature、top_p、max tokens、停止条件。
- 结构化输出：JSON Schema、Pydantic、输出校验。
- 工具调用：函数定义、参数校验、失败重试。
- Prompt 工程：角色、任务、上下文、约束、示例、输出格式。
- 流式响应、并发请求、缓存、限流、成本估算。

### 推荐资料

- OpenAI Prompt Engineering 指南：https://platform.openai.com/docs/guides/prompt-engineering
- OpenAI Agents 指南：https://platform.openai.com/docs/guides/agents
- Anthropic Prompt Engineering：https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview
- OpenAI Cookbook：https://cookbook.openai.com/

### 实战项目

做一个“结构化会议纪要助手”：

- 输入会议转写文本。
- 输出：摘要、行动项、负责人、截止日期、风险、待确认问题。
- 使用 JSON Schema 或 Pydantic 校验输出。
- 支持失败重试和人工修正。
- 增加 prompt 版本记录。

### 验收标准

- 你能把模糊自然语言任务转成稳定输出。
- 你能解释 prompt 为什么这样设计。
- 你能处理模型输出格式错误、信息缺失、超长上下文等问题。

## 5. 阶段 2：RAG 与知识工程

RAG 是企业 Agent 的核心基础设施。多数公司一开始不需要“全自动 Agent”，而是需要可靠地访问内部知识。

### 必学概念

- 文档解析：PDF、Word、HTML、Markdown、表格、图片 OCR。
- Chunking：固定长度、语义切分、标题层级切分、父子 chunk。
- Embedding：向量表示、召回、相似度、维度、成本。
- Hybrid Search：关键词检索 + 向量检索。
- Rerank：重排模型、交叉编码器、召回质量提升。
- 引用与溯源：答案必须绑定原文片段。
- RAG 评测：faithfulness、answer relevance、context precision、context recall。

### 推荐资料

- LlamaIndex 文档：https://docs.llamaindex.ai/
- LangChain RAG 教程：https://python.langchain.com/docs/tutorials/rag/
- Ragas 文档：https://docs.ragas.io/
- OpenAI File Search 文档：https://platform.openai.com/docs/guides/tools-file-search

### 实战项目

做一个“公司制度知识库问答”：

- 支持上传 PDF/Markdown/Docx。
- 自动解析、切分、向量化、入库。
- 支持问题检索、引用来源、原文跳转。
- 支持“找不到就说找不到”，不编造。
- 使用 Ragas 或自定义 eval 集做质量评估。

### 验收标准

- 你能说清楚 chunk size、overlap、metadata、rerank 的取舍。
- 你能用评测数据证明检索质量是否提升。
- 你能避免“看似回答正确但无来源”的系统风险。

## 6. 阶段 3：单 Agent 与工具使用

Agent 的核心不是“会聊天”，而是“能在目标、上下文和工具约束下完成任务”。

### 必学概念

- Agent loop：观察、思考、行动、结果、继续或停止。
- Tool calling：工具 schema、权限、幂等性、超时、错误恢复。
- 状态管理：会话状态、任务状态、工具结果、用户偏好。
- 记忆：短期记忆、长期记忆、用户画像、项目上下文。
- Guardrails：输入校验、输出校验、工具权限、敏感操作审批。
- 人机协同：确认、澄清、审批、回滚。

### 推荐资料

- OpenAI Agents SDK Python：https://openai.github.io/openai-agents-python/
- OpenAI Agents SDK JavaScript：https://openai.github.io/openai-agents-js/
- OpenAI Agents SDK 官方介绍：https://platform.openai.com/docs/guides/agents-sdk/
- OpenAI Agent Evals：https://platform.openai.com/docs/guides/agent-evals

### 实战项目

做一个“个人研究 Agent”：

- 输入一个研究主题。
- 自动拆解问题。
- 调用搜索、网页抓取、本地笔记检索、摘要工具。
- 生成带引用的研究报告。
- 对高风险结论标记不确定性。
- 记录完整 trace。

### 验收标准

- 你能限制 Agent 只能调用必要工具。
- 你能处理工具失败、结果为空、结果冲突。
- 你能让用户复盘 Agent 做过什么、为什么这样做。

## 7. 阶段 4：工作流 Agent

企业落地时，很多场景不应交给完全自由的 Agent，而应使用“确定性工作流 + 局部智能”。

### 必学概念

- DAG、状态机、图式编排。
- 路由节点、判断节点、人工审批节点、重试节点。
- 可恢复长任务：checkpoint、resume、任务快照。
- 批处理、队列、并发、限速。
- 多步骤失败处理和补偿动作。

### 推荐资料

- LangGraph 文档：https://langchain-ai.github.io/langgraph/
- LangGraph Academy：https://academy.langchain.com/
- OpenAI Agents SDK Handoffs 与 Sessions：https://openai.github.io/openai-agents-python/
- Temporal 工作流：https://docs.temporal.io/

### 实战项目

做一个“销售线索处理 Agent Workflow”：

- 输入客户线索。
- 自动补全公司信息。
- 判断客户画像和优先级。
- 生成个性化邮件草稿。
- 人工审批后发送或写入 CRM。
- 全流程可追踪、可重试、可暂停。

### 验收标准

- 你能解释哪些步骤适合 LLM，哪些必须确定性实现。
- 你能实现节点级重试、审批和状态恢复。
- 你能把 Agent 从 demo 变成业务可用流程。

## 8. 阶段 5：多 Agent 系统

多 Agent 不是越多越好。只有当任务天然需要多角色、多视角、并行探索或互相审查时才值得使用。

### 必学概念

- 角色分工：planner、researcher、executor、critic、reviewer。
- 协作协议：轮流发言、黑板模式、主管分配、投票、仲裁。
- 冲突处理：证据优先、置信度、人工介入。
- 成本控制：并行度、早停、模型分层、缓存。
- 质量控制：交叉检查、反事实检查、引用检查。

### 推荐资料

- Microsoft AutoGen AgentChat：https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/index.html
- CrewAI 文档：https://docs.crewai.com/
- LangGraph Multi-agent Systems：https://langchain-ai.github.io/langgraph/concepts/multi_agent/
- OpenAI Practical Guide to Building Agents：https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf

### 实战项目

做一个“竞品分析多 Agent 系统”：

- Planner 负责制定分析框架。
- Researcher 负责收集公开资料。
- Analyst 负责提炼洞察。
- Critic 负责指出证据不足和逻辑漏洞。
- Writer 负责生成最终报告。
- 所有结论必须绑定来源或标记为推断。

### 验收标准

- 你能说明为什么需要多 Agent，而不是一个 Agent。
- 你能避免多 Agent 互相重复、循环讨论、成本失控。
- 你能设计清晰的终止条件和质量门槛。

## 9. 阶段 6：AgentOps 与生产化

这是从中级走向高级的分水岭。高级 Agent 工程师必须能回答：“上线后如何知道它好不好？坏了怎么办？成本失控怎么办？数据泄露怎么办？”

### 必学能力

- Evals：离线评测、在线评测、回归集、人工标注、LLM-as-judge。
- Observability：trace、span、工具调用日志、模型输入输出、成本、延迟。
- 安全：prompt injection、tool injection、数据泄露、越权调用、供应链风险。
- 权限：最小权限、用户身份传递、审批、审计日志。
- 部署：容器化、队列、任务调度、水平扩展、灰度发布。
- 成本治理：模型路由、缓存、批处理、截断、低价模型预处理。

### 推荐资料

- OpenAI Evals：https://evals.openai.com/
- OpenAI Agent Evals：https://platform.openai.com/docs/guides/agent-evals
- LangSmith Observability：https://docs.langchain.com/langsmith/observability-studio
- Langfuse 文档：https://langfuse.com/docs
- OpenAI Prompt Injection 防护文章：https://openai.com/index/designing-agents-to-resist-prompt-injection/
- OWASP Top 10 for LLM Applications：https://owasp.org/www-project-top-10-for-large-language-model-applications/

### 实战项目

做一个“生产级 Agent 服务模板”：

- API 层：FastAPI。
- Agent 层：OpenAI Agents SDK 或 LangGraph。
- Tool 层：数据库查询、HTTP API、本地文件、邮件或 CRM mock。
- Eval 层：固定评测集、回归测试、LLM-as-judge。
- Observability 层：Langfuse 或 LangSmith。
- 安全层：工具白名单、输入清洗、输出校验、人工审批。
- 部署层：Docker Compose，本地一键启动。

### 验收标准

- 任意一次 Agent 执行都能被完整复盘。
- 每次 prompt、工具或模型变更都有回归测试。
- 成本、延迟、失败率、人工介入率都可统计。
- 敏感工具调用必须经过权限和审批控制。

## 10. 阶段 7：MCP 与企业集成

MCP 正在成为 Agent 连接外部工具和数据源的重要协议。高级 Agent 工程师需要理解它的价值，也要理解它的安全边界。

### 必学概念

- MCP Client、Server、Host 的关系。
- Tools、Resources、Prompts。
- STDIO、HTTP/SSE 等传输方式。
- 工具 schema、权限边界、上下文注入。
- 企业内部 MCP Server 的治理：认证、审计、版本、沙箱。

### 推荐资料

- MCP 官方文档：https://modelcontextprotocol.io/
- MCP 架构概览：https://modelcontextprotocol.io/docs/learn/architecture
- MCP GitHub：https://github.com/modelcontextprotocol/modelcontextprotocol
- OpenAI Agents SDK MCP 支持：https://openai.github.io/openai-agents-python/mcp/

### 实战项目

做一个“公司内部工具 MCP Server”：

- 提供查询员工、查询制度、创建工单、查询项目状态等 mock 工具。
- 每个工具都有清晰 schema 和权限说明。
- 高风险工具必须要求人工确认。
- 接入一个 Agent 客户端，让 Agent 能通过 MCP 调用内部能力。

### 验收标准

- 你能解释 MCP 与普通函数调用、插件系统、HTTP API 的区别。
- 你能设计安全的 MCP 工具边界。
- 你能把 MCP 作为公司 Agent 平台的能力接入层。

## 11. 阶段 8：企业从零落地 Agent 的方法论

### 选场景原则

优先选择：

- 高频、重复、规则清晰但需要语言理解的任务。
- 有明确输入输出和可验证结果的任务。
- 人工成本高，但错误风险可控的任务。
- 数据和工具权限容易打通的任务。
- 能在 2 到 4 周内做出 MVP 的任务。

暂缓选择：

- 目标模糊、评判标准不清的任务。
- 需要大量跨部门权限审批的任务。
- 错误会直接造成财务、法律、安全事故的任务。
- 纯靠 Agent 自主决策、没有人工兜底的任务。

### 落地流程

1. 业务访谈：明确当前流程、痛点、成本、失败案例。
2. 场景评分：按价值、可行性、风险、数据可得性打分。
3. POC：用最小数据和 mock 工具验证能力边界。
4. MVP：接入真实数据和有限真实用户。
5. Eval：建立用例集、质量门槛和人工审核标准。
6. 上线：灰度发布、监控、人工兜底、审计。
7. 平台化：沉淀工具、prompt、eval、权限、模板和运维流程。

### 公司 Agent 平台参考架构

```mermaid
flowchart TD
    U["业务用户"] --> UI["Web / IM / IDE / 内部系统入口"]
    UI --> Gateway["Agent Gateway"]
    Gateway --> Auth["身份、权限、审计"]
    Gateway --> Runtime["Agent Runtime"]
    Runtime --> Planner["规划与路由"]
    Runtime --> Tools["工具调用层"]
    Runtime --> Memory["记忆与上下文层"]
    Tools --> MCP["MCP Servers"]
    Tools --> APIs["内部 API / SaaS / 数据库"]
    Memory --> VectorDB["向量库"]
    Memory --> SQL["业务数据库"]
    Runtime --> Eval["Eval 与 Guardrails"]
    Runtime --> Obs["Tracing / Logs / Metrics"]
    Eval --> Human["人工审批与标注"]
    Obs --> Dashboard["质量、成本、延迟看板"]
```

## 12. 推荐技术栈

### 入门到进阶主线

- 语言：Python 优先，TypeScript 作为补充。
- API：FastAPI。
- Agent 框架：OpenAI Agents SDK、LangGraph。
- RAG：LlamaIndex 或 LangChain。
- 向量库：pgvector、Qdrant、Milvus、Pinecone 任选其一。
- 评测：OpenAI Evals、Ragas、自定义 pytest eval。
- 可观测性：Langfuse 或 LangSmith。
- 协议：MCP。
- 部署：Docker、PostgreSQL、Redis、Celery/RQ、Kubernetes 可后置。

### 选型建议

| 需求 | 优先方案 |
| --- | --- |
| 快速构建单 Agent | OpenAI Agents SDK |
| 需要可控复杂流程 | LangGraph |
| 文档问答和知识库 | LlamaIndex |
| 多 Agent 研究或协作 demo | AutoGen / CrewAI |
| 企业工具统一接入 | MCP |
| 质量回归和评估 | OpenAI Evals / Ragas |
| 生产 trace 和调试 | Langfuse / LangSmith |

## 13. 必做项目清单

按顺序完成这些项目，比零散看教程更重要。

1. 结构化会议纪要助手
2. 企业知识库 RAG 问答
3. 带工具调用的个人研究 Agent
4. 可审批的销售线索工作流 Agent
5. 多 Agent 竞品分析系统
6. MCP 内部工具服务器
7. 生产级 Agent 服务模板
8. 公司 Agent 落地方案与 ROI 测算文档

每个项目都必须包含：

- README：目标、架构、运行方式。
- Eval 集：至少 20 条测试用例。
- Trace：至少能查看一次完整执行链路。
- Failure cases：记录失败样例和修复策略。
- Cost report：估算每次任务成本。
- Security notes：列出权限、注入、隐私风险。

## 14. 每周学习节奏

### 工作日

- 30 分钟：读官方文档或源码。
- 60 分钟：写代码实现一个小功能。
- 20 分钟：记录问题、失败案例、prompt 版本。
- 10 分钟：复盘今天学到的模式。

### 周末

- 半天：推进一个完整项目功能。
- 1 小时：补 eval。
- 1 小时：整理 README 和架构图。
- 30 分钟：写一篇技术笔记。

## 15. 高级能力检查表

当你能稳定完成以下事项，才算接近高级 Agent 工程师：

- 能在需求阶段判断是否应该使用 Agent，而不是盲目上 Agent。
- 能设计 Agent 的工具边界、权限边界和人工审批点。
- 能把任务拆成确定性流程和 LLM 判断节点。
- 能实现 RAG、工具调用、长任务状态、失败重试和恢复。
- 能搭建 eval 集，并用数据证明版本改动是否变好。
- 能看 trace 定位失败来自 prompt、模型、检索、工具还是业务规则。
- 能控制成本、延迟、并发和模型路由。
- 能防御基本 prompt injection 和 tool injection。
- 能给业务方讲清楚 ROI、风险和上线边界。
- 能把一次性 demo 沉淀为可复用平台能力。

## 16. 进阶阅读与研究方向

### 论文与理论

- ReAct：Reasoning and Acting in Language Models
- Toolformer：Language Models Can Teach Themselves to Use Tools
- Reflexion：Language Agents with Verbal Reinforcement Learning
- Self-RAG：Learning to Retrieve, Generate, and Critique
- RAGAS：Automated Evaluation of Retrieval Augmented Generation

### 工程方向

- Agent memory 设计。
- Long-running agents 与 checkpoint。
- Computer use / browser use。
- Code agents 与软件工程自动化。
- Multi-agent coordination。
- LLM security。
- Agent eval 与自动化红队。
- 企业 Agent 平台治理。

## 17. 最重要的学习原则

- 少看“炫技 demo”，多做“可评测、可复盘、可上线”的项目。
- 不要一开始就迷信多 Agent。先学会单 Agent 和工作流 Agent。
- 不要把 prompt 当魔法。prompt 必须版本化、测试化、数据化。
- 不要把工具权限随意暴露给模型。工具是能力，也是风险。
- 不要只评估最终答案。要评估检索、规划、工具调用、步骤质量和成本。
- 不要等系统完美才上线。用灰度、审批、审计和 eval 管住风险。

## 18. 90 天里程碑

### 第 1-30 天

- 完成 Python/FastAPI 基础服务。
- 完成结构化会议纪要助手。
- 熟悉 OpenAI API、prompt、结构化输出、工具调用。

### 第 31-60 天

- 完成企业知识库 RAG。
- 建立第一版 RAG eval 集。
- 学会 LlamaIndex 或 LangChain 的基础用法。

### 第 61-90 天

- 完成个人研究 Agent。
- 完成一个 LangGraph 或 OpenAI Agents SDK 工作流。
- 接入 Langfuse/LangSmith 做 trace。
- 写出第一版公司 Agent 落地方案。

90 天后，你应该已经不是“会调 API 的开发者”，而是能独立设计、实现和评估 Agent MVP 的工程师。之后的重点是生产化、安全、平台化和真实业务 ROI。

